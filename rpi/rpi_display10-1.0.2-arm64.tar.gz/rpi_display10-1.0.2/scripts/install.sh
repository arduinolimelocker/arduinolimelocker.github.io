#!/usr/bin/env bash
# Instala o rpi_display10 no Raspberry Pi: compila, copia para /opt e registra
# o serviço systemd que sobe o display sozinho no boot.
#
# Rode este script NO PRÓPRIO Raspberry Pi (não é cross-compile), a partir da
# raiz do projeto:
#   cd rpi_display10
#   sudo ./scripts/install.sh
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
    echo "Rode como root (sudo ./scripts/install.sh)." >&2
    exit 1
fi

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
INSTALL_DIR="/opt/rpi_display10"

if [ -f "$PROJECT_DIR/rpi_display10" ] && [ -f "$PROJECT_DIR/VERSION" ] && [ ! -f "$PROJECT_DIR/CMakeLists.txt" ]; then
    echo "==> Pacote pronto $(cat "$PROJECT_DIR/VERSION") ($(cat "$PROJECT_DIR/ARCH")): instalando sem compilar..."
    if [ "$(cat "$PROJECT_DIR/ARCH")" != "$(dpkg --print-architecture)" ]; then
        echo "ERRO: pacote para $(cat "$PROJECT_DIR/ARCH"), mas este Pi e $(dpkg --print-architecture). Use o Raspberry Pi OS 64 bits." >&2
        exit 1
    fi
    if ! (cd "$PROJECT_DIR" && sha256sum -c --quiet SHA256SUMS); then
        echo "ERRO: arquivos do pacote corrompidos (SHA256SUMS nao confere). Copie o pacote de novo." >&2
        exit 1
    fi
    if ! command -v python3 >/dev/null 2>&1; then
        apt-get update -y
        apt-get install -y --no-install-recommends python3
    fi
    BIN="$PROJECT_DIR/rpi_display10"
else
    echo "==> Instalando dependências de build (se faltarem)..."
    apt-get update -y
    apt-get install -y --no-install-recommends \
        build-essential cmake git ca-certificates python3

    echo "==> Compilando (isso baixa a LVGL na primeira vez — pode levar alguns minutos no Pi 3B)..."
    cd "$PROJECT_DIR"
    rm -rf build
    mkdir -p build
    cd build
    cmake -DCMAKE_BUILD_TYPE=Release ..
    cmake --build . -j"$(nproc)"
    BIN="$PROJECT_DIR/build/rpi_display10"
fi

APP_VERSION="$("$BIN" --version)"
RELEASE_DIR="$INSTALL_DIR/releases/$APP_VERSION"
echo "==> Instalando binário (versão $APP_VERSION) em ${RELEASE_DIR}..."
mkdir -p "$RELEASE_DIR" "$INSTALL_DIR/bin" /var/lib/rpi-display
install -m 0755 "$BIN" "$RELEASE_DIR/rpi_display10"
echo "$APP_VERSION" > "$RELEASE_DIR/VERSION"
dpkg --print-architecture > "$RELEASE_DIR/ARCH"
ln -sfn "releases/$APP_VERSION" "$INSTALL_DIR/current"
ln -sfn "current/rpi_display10" "$INSTALL_DIR/rpi_display10"
install -m 0755 "$PROJECT_DIR/scripts/rpi-display-update.py" "$INSTALL_DIR/bin/rpi-display-update"

echo "==> Instalando serviço systemd..."
install -m 0644 "$PROJECT_DIR/systemd/can0-up.service" /etc/systemd/system/can0-up.service
install -m 0644 "$PROJECT_DIR/systemd/rpi-display.service" /etc/systemd/system/rpi-display.service
install -m 0644 "$PROJECT_DIR/systemd/rpi-display-update.service" /etc/systemd/system/rpi-display-update.service
systemctl daemon-reload
systemctl enable can0-up.service
systemctl enable rpi-display.service

echo "==> Conferindo arquivo de configuração de rotação da tela..."
# Não sobrescreve se já existir — preserva a rotação já escolhida em
# reinstalações/atualizações.
mkdir -p /etc/rpi-display
if [ ! -f /etc/rpi-display/display.conf ]; then
    cat > /etc/rpi-display/display.conf <<'EOF'
# Fonte dos dados de pedidos exibidos na tela.
#
#   can     (padrão) - lê direto do barramento CAN do armário (can0), sem
#                       depender do ESP32-S3 como ponte serial. Requer o
#                       overlay mcp2515-can0 (ver abaixo) e o serviço
#                       can0-up.service (instalado junto por este script).
#   serial            - modo antigo: recebe comandos SET:/CLR:/VIS:/COL: via
#                       porta serial, enviados pelo ESP32-S3.
#
# Depois de mudar, aplique com:
#   sudo systemctl restart rpi-display.service
# Não precisa recompilar nem reinstalar.
RPI_DISPLAY_SOURCE=can

# Rotação da tela do display de pedidos (Raspberry Pi).
#
# Valores aceitos (o "esquerda"/"direita" indica de qual lado do
# gabinete/locker sai o cabo HDMI/energia depois de montado, não a imagem em
# si — cada par abaixo é a mesma orientação girada 180°):
#
#   paisagem-esquerda   (padrão, 0°)
#   retrato-esquerda    (90°)
#   paisagem-direita    (180°)
#   retrato-direita     (270°)
#
# Depois de mudar, aplique com:
#   sudo systemctl restart rpi-display.service
# Não precisa recompilar nem reinstalar.
RPI_DISPLAY_ROTATION=paisagem-esquerda
EOF
    echo "    Criado /etc/rpi-display/display.conf (RPI_DISPLAY_SOURCE=can, RPI_DISPLAY_ROTATION=paisagem-esquerda)."
else
    echo "    /etc/rpi-display/display.conf já existe — mantido sem alteração."
fi

echo "==> Desabilitando qualquer console de texto (getty) em qualquer tty..."
# Qualquer console de texto do Linux (tty1, tty2, ...) e o nosso app disputam
# o MESMO /dev/fb0. Sem isso, o prompt de login / cursor piscando é
# redesenhado por cima do display (ou vice-versa). Não basta mascarar só a
# tty1: o autovt@.service é o mecanismo que faz o systemd criar um getty
# automaticamente sempre que alguém troca de VT (Ctrl+Alt+F2, etc.) — sem
# mascarar o template, uma tty2/tty3/... pode nascer depois e voltar a
# brigar pela tela.
REBOOT_NEEDED=0
systemctl stop getty@tty1.service getty@tty2.service 2>/dev/null || true
systemctl disable getty@tty1.service getty@tty2.service 2>/dev/null || true
systemctl mask getty@tty1.service getty@tty2.service autovt@.service

CMDLINE_FILE=""
if [ -f /boot/firmware/cmdline.txt ]; then
    CMDLINE_FILE="/boot/firmware/cmdline.txt"
elif [ -f /boot/cmdline.txt ]; then
    CMDLINE_FILE="/boot/cmdline.txt"
fi

if [ -n "$CMDLINE_FILE" ]; then
    if ! grep -q "vt.global_cursor_default=0" "$CMDLINE_FILE"; then
        sed -i 's/$/ vt.global_cursor_default=0 consoleblank=0 fbcon=map:10 loglevel=3 quiet/' "$CMDLINE_FILE"
        echo "    Adicionado 'vt.global_cursor_default=0 consoleblank=0 fbcon=map:10 loglevel=3 quiet' em $CMDLINE_FILE."
        REBOOT_NEEDED=1
    else
        echo "    $CMDLINE_FILE já estava ajustado."
    fi
else
    echo "    AVISO: não encontrei /boot/cmdline.txt nem /boot/firmware/cmdline.txt."
    echo "    Adicione manualmente 'vt.global_cursor_default=0 consoleblank=0 fbcon=map:10"
    echo "    loglevel=3 quiet' na única linha desse arquivo (mesma linha, separado por"
    echo "    espaço, sem quebrar linha)."
fi

echo "==> Conferindo se o driver de vídeo moderno (VC4 KMS) está ativo..."
# CRÍTICO: sem isso, o /dev/fb0 é o framebuffer LEGADO (gerenciado pelo
# firmware da GPU, sem sincronismo de vídeo real — "timings" zerados no
# fbset). Nesse driver legado, o app consegue desenhar a tela uma vez, mas
# atualizações pontuais de pedidos (SET:) não aparecem, e a tentativa de
# forçar uma reativação de tela (force_refresh) derruba a saída de vídeo por
# completo. Confirmamos isso na prática: só funciona direito com o driver
# moderno (vc4-kms-v3d), que faz o commit de cada frame de forma confiável.
CONFIG_FILE=""
if [ -f /boot/firmware/config.txt ]; then
    CONFIG_FILE="/boot/firmware/config.txt"
elif [ -f /boot/config.txt ]; then
    CONFIG_FILE="/boot/config.txt"
fi

if [ -n "$CONFIG_FILE" ]; then
    if ! grep -q "^dtoverlay=vc4-kms-v3d" "$CONFIG_FILE"; then
        if grep -q "# Enable DRM VC4 V3D driver" "$CONFIG_FILE"; then
            sed -i '/# Enable DRM VC4 V3D driver/a dtoverlay=vc4-kms-v3d' "$CONFIG_FILE"
        else
            printf '\n# Enable DRM VC4 V3D driver (necessario - ver README)\ndtoverlay=vc4-kms-v3d\n' >> "$CONFIG_FILE"
        fi
        echo "    Adicionado 'dtoverlay=vc4-kms-v3d' em $CONFIG_FILE."
        REBOOT_NEEDED=1
    else
        echo "    $CONFIG_FILE já tem o driver moderno habilitado."
    fi
else
    echo "    AVISO: não encontrei /boot/config.txt nem /boot/firmware/config.txt."
    echo "    Adicione manualmente 'dtoverlay=vc4-kms-v3d' nesse arquivo e reinicie."
fi

echo "==> Configurando a UART de hardware (GPIO14/15 — /dev/ttyAMA0)..."
# A versão do raspi-config lida no código-fonte do GitHub (RPi-Distro/raspi-config,
# branch master) tem um do_serial() unificado com um único argumento (0/1/2), mas
# na prática, testado no hardware real (Raspberry Pi OS Bookworm), esse comando
# unificado ficou interativo (não respeitou o modo não-interativo). O que
# funciona de verdade nessa versão são os comandos SEPARADOS abaixo — validado
# rodando direto no Pi:
#   do_serial_cons 1 -> desabilita o login shell sobre serial
#   do_serial_hw  0 -> habilita a UART de hardware
if command -v raspi-config >/dev/null 2>&1; then
    SERIAL_CONSOLE_ON="$(raspi-config nonint get_serial 2>/dev/null || echo 1)"      # 0 = console habilitado
    SERIAL_HW_ON="$(raspi-config nonint get_serial_hw 2>/dev/null || echo 1)"        # 0 = UART hw habilitada
    if [ "$SERIAL_CONSOLE_ON" = "0" ] || [ "$SERIAL_HW_ON" != "0" ]; then
        raspi-config nonint do_serial_cons 1
        raspi-config nonint do_serial_hw 0
        echo "    Login shell sobre serial desabilitado, UART de hardware habilitada."
        REBOOT_NEEDED=1
    else
        echo "    UART de hardware já estava configurada corretamente (sem login shell)."
    fi
else
    echo "    AVISO: 'raspi-config' não encontrado neste sistema — configure"
    echo "    manualmente: raspi-config -> Interface Options -> Serial Port."
fi

echo "==> Desabilitando o Bluetooth (libera a UART de hardware, que senão fica"
echo "    ocupada pelo Bluetooth em vez de ficar livre pro ESP32-S3)..."
if [ -n "$CONFIG_FILE" ]; then
    if ! grep -q "^dtoverlay=disable-bt" "$CONFIG_FILE"; then
        printf '\n# Libera a UART de hardware pro ESP32-S3 (desliga o Bluetooth, que a usa)\ndtoverlay=disable-bt\n' >> "$CONFIG_FILE"
        echo "    Adicionado 'dtoverlay=disable-bt' em $CONFIG_FILE."
        REBOOT_NEEDED=1
    else
        echo "    $CONFIG_FILE já tem o Bluetooth desabilitado."
    fi
else
    echo "    AVISO: não encontrei config.txt — adicione 'dtoverlay=disable-bt' manualmente."
fi

echo "==> Conferindo overlay do módulo CAN (MCP2515 -> can0)..."
# Necessário para RPI_DISPLAY_SOURCE=can (o padrão deste script). Ver
# claude/plano-arquitetura-display-raspberry.md para o esquema de ligação
# Pi -> level shifters -> módulo CAN -> barramento compartilhado com o S3.
if [ -n "$CONFIG_FILE" ]; then
    if ! grep -q "^dtparam=spi=on" "$CONFIG_FILE"; then
        printf '\ndtparam=spi=on\n' >> "$CONFIG_FILE"
        echo "    Adicionado 'dtparam=spi=on' em $CONFIG_FILE."
        REBOOT_NEEDED=1
    else
        echo "    $CONFIG_FILE já tem o SPI habilitado."
    fi
    if ! grep -q "^dtoverlay=mcp2515-can0" "$CONFIG_FILE"; then
        printf '\n# Módulo CAN (MCP2515) ligado ao barramento do armário\ndtoverlay=mcp2515-can0,oscillator=8000000,interrupt=25,spimaxfrequency=1000000\n' >> "$CONFIG_FILE"
        echo "    Adicionado 'dtoverlay=mcp2515-can0,...' em $CONFIG_FILE."
        REBOOT_NEEDED=1
    else
        echo "    $CONFIG_FILE já tem o overlay do MCP2515 habilitado."
    fi
else
    echo "    AVISO: não encontrei config.txt — configure manualmente 'dtparam=spi=on' e"
    echo "    'dtoverlay=mcp2515-can0,oscillator=8000000,interrupt=25,spimaxfrequency=1000000'."
fi

echo
echo "==> Pronto. Antes de iniciar, confirme:"
echo "    1. O caminho do framebuffer e da porta serial em"
echo "       /etc/systemd/system/rpi-display.service (ExecStart)."
echo "       Veja o README.md - 'Descobrindo os caminhos certos'."
echo "    2. Depois de reiniciar, confirme que o driver certo está ativo:"
echo "       cat /sys/class/graphics/fb0/name   (deve mostrar 'vc4drmfb')"
echo
echo "==> Para iniciar agora:"
echo "    sudo systemctl start rpi-display.service"
echo "==> Para acompanhar os logs:"
echo "    journalctl -u rpi-display.service -f"

if [ "$REBOOT_NEEDED" -eq 1 ]; then
    echo
    echo "==> IMPORTANTE: foram alterados cmdline.txt e/ou config.txt."
    echo "    É preciso REINICIAR antes de iniciar o serviço: sudo reboot"
fi
