#!/usr/bin/env python3
import hashlib
import json
import os
import shutil
import socket
import struct
import subprocess
import sys
import tarfile
import time
import urllib.error
import urllib.request

BASE_DIR = "/opt/rpi_display10"
RELEASES_DIR = BASE_DIR + "/releases"
CURRENT_LINK = BASE_DIR + "/current"
PREVIOUS_LINK = BASE_DIR + "/previous"
BIN_LINK = BASE_DIR + "/rpi_display10"
STATE_DIR = "/var/lib/rpi-display"
REQ_FILE = STATE_DIR + "/update.req"
DOWNLOAD_DIR = STATE_DIR + "/download"
RUNNING_FILE = "/run/rpi-display/running"
URL_PREFIX = "https://arduinolimelocker.github.io/"
CAN_IF = os.environ.get("RPI_DISPLAY_CAN_IF", "can0")
SERVICE = "rpi-display.service"

STATUS_CAN_ID = 0x1C0
CODE_PROGRESS = 0x10
CODE_INSTALLING = 0x11
CODE_OK = 0x20
CODE_UP_TO_DATE = 0x21
CODE_FAIL = 0x30

REASON_URL = 3
REASON_NETWORK = 4
REASON_DESCRIPTOR = 5
REASON_ARCH = 6
REASON_DOWNLOAD = 7
REASON_CHECKSUM = 8
REASON_INSTALL = 9
REASON_ROLLBACK = 10
REASON_DISK = 11

HTTP_TIMEOUT_S = 30
PROGRESS_EVERY_S = 10
START_WAIT_S = 30
STABLE_WAIT_S = 15
DISK_MARGIN = 20 * 1024 * 1024


def log(msg):
    print("[rpi-display-update] " + msg, flush=True)


class Fail(Exception):
    def __init__(self, reason, detail):
        super().__init__(detail)
        self.reason = reason


class Request:
    def __init__(self, session, force, url):
        self.session = session
        self.force = force
        self.url = url


class Can:
    def __init__(self, session):
        self.session = session
        self.sock = None
        try:
            self.sock = socket.socket(socket.AF_CAN, socket.SOCK_RAW, socket.CAN_RAW)
            self.sock.bind((CAN_IF,))
        except OSError as e:
            log("CAN indisponivel (%s): status nao serao enviados" % e)
            self.sock = None

    def send(self, code, arg=0, version=(0, 0, 0)):
        log("status 0x%02x arg=%d versao=%s" % (code, arg, ".".join(str(v) for v in version)))
        if self.sock is None:
            return
        data = bytes([code, self.session & 0xFF, (self.session >> 8) & 0xFF, arg & 0xFF,
                      version[0], version[1], version[2], 0])
        frame = struct.pack("=IB3x8s", STATUS_CAN_ID, 8, data)
        for _ in range(3):
            try:
                self.sock.send(frame)
                return
            except OSError as e:
                log("falha ao enviar no CAN: %s" % e)
                time.sleep(0.05)


def read_request():
    with open(REQ_FILE) as f:
        lines = [line.strip() for line in f.read().splitlines()]
    if len(lines) < 3:
        raise ValueError("pedido incompleto")
    return Request(int(lines[0]) & 0xFFFF, lines[1] == "1", lines[2])


def parse_version(text):
    parts = text.strip().split(".")
    if not 1 <= len(parts) <= 3 or not all(p.isdigit() for p in parts):
        raise ValueError(text)
    nums = [int(p) for p in parts] + [0] * (3 - len(parts))
    if any(n > 255 for n in nums):
        raise ValueError(text)
    return tuple(nums)


def machine_arch():
    try:
        return subprocess.run(["dpkg", "--print-architecture"], capture_output=True,
                              text=True, timeout=10, check=True).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return os.uname().machine


def current_version():
    try:
        with open(CURRENT_LINK + "/VERSION") as f:
            return f.read().strip()
    except OSError:
        return ""


def atomic_symlink(target, link):
    tmp = link + ".tmp"
    if os.path.lexists(tmp):
        os.remove(tmp)
    os.symlink(target, tmp)
    os.replace(tmp, link)


def ensure_layout():
    os.makedirs(RELEASES_DIR, exist_ok=True)
    if not os.path.islink(CURRENT_LINK):
        legacy = RELEASES_DIR + "/legacy"
        if os.path.isfile(BIN_LINK) and not os.path.islink(BIN_LINK):
            os.makedirs(legacy, exist_ok=True)
            shutil.copy2(BIN_LINK, legacy + "/rpi_display10")
            with open(legacy + "/VERSION", "w") as f:
                f.write("0.0.0\n")
            atomic_symlink("releases/legacy", CURRENT_LINK)
            log("instalacao antiga movida para releases/legacy")
    if os.path.islink(CURRENT_LINK) and not os.path.islink(BIN_LINK):
        atomic_symlink("current/rpi_display10", BIN_LINK)


def fetch_descriptor(url):
    try:
        with urllib.request.urlopen(url, timeout=HTTP_TIMEOUT_S) as r:
            raw = r.read(64 * 1024)
    except urllib.error.HTTPError as e:
        raise Fail(REASON_DESCRIPTOR, "descritor HTTP %d" % e.code)
    except (urllib.error.URLError, OSError) as e:
        raise Fail(REASON_NETWORK, "sem acesso ao descritor: %s" % e)
    try:
        desc = json.loads(raw.decode("utf-8"))
        version = str(desc["swVersion"]).strip()
        arch = str(desc["swArch"]).strip()
        pkg_url = str(desc["swURL"]).strip()
        size = int(desc["swSize"])
        sha = str(desc["swSha256"]).strip().lower()
        parse_version(version)
    except (ValueError, KeyError, TypeError) as e:
        raise Fail(REASON_DESCRIPTOR, "descritor invalido: %s" % e)
    if not pkg_url.startswith(URL_PREFIX):
        raise Fail(REASON_URL, "URL do pacote fora do site permitido: %s" % pkg_url)
    if size <= 0 or len(sha) != 64:
        raise Fail(REASON_DESCRIPTOR, "tamanho ou sha256 invalidos")
    return version, arch, pkg_url, size, sha


def download(url, size, sha, can):
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    path = DOWNLOAD_DIR + "/package.tar.gz"
    h = hashlib.sha256()
    got = 0
    last_pct = -1
    last_sent = 0.0
    try:
        with urllib.request.urlopen(url, timeout=HTTP_TIMEOUT_S) as r, open(path, "wb") as out:
            while True:
                chunk = r.read(64 * 1024)
                if not chunk:
                    break
                out.write(chunk)
                h.update(chunk)
                got += len(chunk)
                if got > size:
                    raise Fail(REASON_CHECKSUM, "pacote maior que o descritor")
                pct = min(99, got * 100 // size)
                now = time.monotonic()
                if pct // 10 != last_pct // 10 or now - last_sent >= PROGRESS_EVERY_S:
                    can.send(CODE_PROGRESS, pct)
                    last_pct = pct
                    last_sent = now
    except urllib.error.HTTPError as e:
        raise Fail(REASON_DOWNLOAD, "pacote HTTP %d" % e.code)
    except (urllib.error.URLError, OSError) as e:
        raise Fail(REASON_DOWNLOAD, "download interrompido: %s" % e)
    if got != size:
        raise Fail(REASON_CHECKSUM, "tamanho %d, esperado %d" % (got, size))
    if h.hexdigest() != sha:
        raise Fail(REASON_CHECKSUM, "sha256 nao confere")
    can.send(CODE_PROGRESS, 100)
    return path


def safe_extract(path, version, dest):
    prefix = "rpi_display10-%s/" % version
    with tarfile.open(path, "r:gz") as tar:
        members = tar.getmembers()
        for m in members:
            name = m.name
            if name.rstrip("/") + "/" == prefix:
                continue
            if not name.startswith(prefix) or ".." in name.split("/") or name.startswith("/"):
                raise Fail(REASON_INSTALL, "caminho invalido no pacote: %s" % name)
            if not (m.isfile() or m.isdir()):
                raise Fail(REASON_INSTALL, "tipo de arquivo invalido no pacote: %s" % name)
        for m in members:
            rel = m.name[len(prefix):] if m.name.startswith(prefix) else ""
            if not rel:
                continue
            target = os.path.join(dest, rel)
            if m.isdir():
                os.makedirs(target, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            src = tar.extractfile(m)
            with open(target, "wb") as out:
                shutil.copyfileobj(src, out)
            os.chmod(target, m.mode & 0o755)


def verify_release(dest, version, arch):
    sums = os.path.join(dest, "SHA256SUMS")
    if not os.path.isfile(sums):
        raise Fail(REASON_INSTALL, "pacote sem SHA256SUMS")
    with open(sums) as f:
        for line in f:
            parts = line.split()
            if len(parts) != 2:
                continue
            expected, name = parts
            name = name.lstrip("*")
            fpath = os.path.join(dest, name)
            if ".." in name.split("/") or not os.path.isfile(fpath):
                raise Fail(REASON_INSTALL, "arquivo ausente: %s" % name)
            with open(fpath, "rb") as g:
                if hashlib.sha256(g.read()).hexdigest() != expected:
                    raise Fail(REASON_CHECKSUM, "arquivo corrompido: %s" % name)
    for name, want in (("VERSION", version), ("ARCH", arch)):
        with open(os.path.join(dest, name)) as f:
            if f.read().strip() != want:
                raise Fail(REASON_INSTALL, "%s do pacote nao confere" % name)
    binary = os.path.join(dest, "rpi_display10")
    try:
        out = subprocess.run([binary, "--version"], capture_output=True, text=True,
                             timeout=10).stdout.strip()
    except (OSError, subprocess.SubprocessError) as e:
        raise Fail(REASON_INSTALL, "binario nao executa: %s" % e)
    if out != version:
        raise Fail(REASON_INSTALL, "binario informa versao '%s'" % out)


def install_release(path, version, arch):
    final = os.path.join(RELEASES_DIR, version)
    tmp = os.path.join(RELEASES_DIR, ".tmp-%s-%d" % (version, os.getpid()))
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    try:
        safe_extract(path, version, tmp)
        verify_release(tmp, version, arch)
        if os.path.isdir(final):
            old = os.path.join(RELEASES_DIR, ".old-%s-%d" % (version, os.getpid()))
            os.replace(final, old)
        os.replace(tmp, final)
    except Fail:
        shutil.rmtree(tmp, ignore_errors=True)
        raise
    except OSError as e:
        shutil.rmtree(tmp, ignore_errors=True)
        raise Fail(REASON_INSTALL, "falha ao instalar: %s" % e)
    return "releases/" + version


def systemctl(*args):
    return subprocess.run(["systemctl"] + list(args), capture_output=True, text=True,
                          timeout=60)


def service_prop(name):
    return systemctl("show", "-p", name, "--value", SERVICE).stdout.strip()


def restart_service():
    try:
        os.remove(RUNNING_FILE)
    except OSError:
        pass
    systemctl("restart", SERVICE)


def running_version():
    try:
        with open(RUNNING_FILE) as f:
            return f.read().strip()
    except OSError:
        return ""


def healthy(version):
    deadline = time.monotonic() + START_WAIT_S
    while time.monotonic() < deadline:
        if running_version() == version and service_prop("ActiveState") == "active":
            break
        time.sleep(1)
    else:
        log("a versao %s nao subiu em %d s" % (version, START_WAIT_S))
        return False
    pid = service_prop("MainPID")
    restarts = service_prop("NRestarts")
    time.sleep(STABLE_WAIT_S)
    ok = (service_prop("ActiveState") == "active" and service_prop("MainPID") == pid
          and service_prop("NRestarts") == restarts and running_version() == version)
    if not ok:
        log("a versao %s nao ficou estavel" % version)
    return ok


def switch_to(target):
    previous = os.readlink(CURRENT_LINK) if os.path.islink(CURRENT_LINK) else None
    atomic_symlink(target, CURRENT_LINK)
    if previous and previous != target:
        atomic_symlink(previous, PREVIOUS_LINK)
    if not os.path.islink(BIN_LINK):
        atomic_symlink("current/rpi_display10", BIN_LINK)
    restart_service()


def rollback():
    if not os.path.islink(PREVIOUS_LINK):
        log("sem versao anterior para voltar")
        return
    atomic_symlink(os.readlink(PREVIOUS_LINK), CURRENT_LINK)
    restart_service()
    log("voltou para %s" % os.readlink(CURRENT_LINK))


def prune():
    keep = set()
    for link in (CURRENT_LINK, PREVIOUS_LINK):
        if os.path.islink(link):
            keep.add(os.path.basename(os.readlink(link)))
    for name in os.listdir(RELEASES_DIR):
        if name not in keep:
            shutil.rmtree(os.path.join(RELEASES_DIR, name), ignore_errors=True)


def run(req, can):
    if not req.url.startswith(URL_PREFIX):
        raise Fail(REASON_URL, "URL fora do site permitido: %s" % req.url)
    can.send(CODE_PROGRESS, 0)
    ensure_layout()
    version, arch, pkg_url, size, sha = fetch_descriptor(req.url)
    vt = parse_version(version)
    log("descritor: versao %s, arquitetura %s, %d bytes" % (version, arch, size))
    if arch != machine_arch():
        raise Fail(REASON_ARCH, "pacote %s, este Pi e %s" % (arch, machine_arch()))
    if not req.force and current_version() == version:
        log("ja esta na versao %s" % version)
        can.send(CODE_UP_TO_DATE, 0, vt)
        return
    if shutil.disk_usage(STATE_DIR).free < size * 4 + DISK_MARGIN:
        raise Fail(REASON_DISK, "pouco espaco em disco")
    path = download(pkg_url, size, sha, can)
    target = install_release(path, version, arch)
    can.send(CODE_INSTALLING)
    switch_to(target)
    if not healthy(version):
        rollback()
        raise Fail(REASON_ROLLBACK, "versao %s recusada, voltou para a anterior" % version)
    prune()
    log("atualizado para %s" % version)
    can.send(CODE_OK, 0, vt)


def main():
    try:
        req = read_request()
    except (OSError, ValueError) as e:
        log("sem pedido valido: %s" % e)
        return 1
    can = Can(req.session)
    log("sessao %04x: %s%s" % (req.session, "force " if req.force else "", req.url))
    try:
        run(req, can)
        return 0
    except Fail as e:
        log("FALHA: %s" % e)
        can.send(CODE_FAIL, e.reason)
        return 1
    except Exception as e:
        log("ERRO inesperado: %r" % e)
        can.send(CODE_FAIL, REASON_INSTALL)
        return 1
    finally:
        try:
            os.remove(REQ_FILE)
        except OSError:
            pass
        shutil.rmtree(DOWNLOAD_DIR, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
